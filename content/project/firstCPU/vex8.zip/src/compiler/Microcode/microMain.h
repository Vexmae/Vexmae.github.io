#pragma once

#include <vector>
#include <fstream>
#include <iostream>
#include <string>

int microMain(char sourceFile[]);
std::vector<std::string> seperateInstruction(char sourceFile[]);
std::vector<unsigned char> translateToByte(std::vector<std::string> instructionList);
unsigned char convertNumber(std::string number);
int writeToBin(std::vector<unsigned char> bytelist);