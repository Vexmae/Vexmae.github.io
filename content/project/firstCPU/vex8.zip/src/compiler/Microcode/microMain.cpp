#include "microMain.h"

int microMain(char sourceFile[]) {
    writeToBin(translateToByte(seperateInstruction(sourceFile)));
	return 0;
}

std::vector<std::string> seperateInstruction(char sourceFile[]) {
	std::ifstream sourceStream;
	sourceStream.open(sourceFile, std::ios::in);

	std::vector<std::string> instructions;
	std::string currentline;
	instructions.push_back("NOOP"); //This prevent the RST pin to skip the first instruction
	while (std::getline(sourceStream, currentline)) {
		std::string x;
		currentline.append(std::string("\n"));
		for (int i = 0; i < currentline.size(); i++) {
			if (currentline.c_str()[i] != ' ' && currentline.c_str()[i] != '\n') {
				x.push_back(currentline.c_str()[i]);
			} else if(currentline.c_str()[i] == ';'){
				break;
			} else {
				instructions.push_back(x);
				x = "";
			}
		}
	}
	std::cout << "INFO: " << instructions.size() << " instruction found.\n";
	return instructions;
}

std::vector<unsigned char> translateToByte(std::vector<std::string> instructionList) {
	std::vector<unsigned char> byte;
	bool data = false;
	
	for (int i = 0; i < instructionList.size(); i++) {
		if (data) { byte.push_back(convertNumber(instructionList[i])); data = false; }
		else if (instructionList[i] == "ABUS") { byte.push_back(0x00); }
		else if (instructionList[i]== "BBUS") { byte.push_back(0x02); }
		else if (instructionList[i]== "CBUS") { byte.push_back(0x04); }
		else if (instructionList[i]== "SPBUS") { byte.push_back(0x05); }
		else if (instructionList[i]== "ADLBUS") { byte.push_back(0x06); }
		else if (instructionList[i]== "ADHBUS") { byte.push_back(0x07); }
		else if (instructionList[i]== "RAMBUS") { byte.push_back(0x0A); }
		else if (instructionList[i]== "ALUBUS") { byte.push_back(0x0B); }
		else if (instructionList[i]== "LSBUS") { byte.push_back(0x0C); }
		else if (instructionList[i]== "RSBUS") { byte.push_back(0x0D); }
		else if (instructionList[i]== "CUBUS") { byte.push_back(0x0E); }
	
		else if (instructionList[i]== "BUSA") { byte.push_back(0x11); }
		else if (instructionList[i]== "BUSB") { byte.push_back(0x12); }
		else if (instructionList[i]== "BUSC") { byte.push_back(0x13); }
		else if (instructionList[i]== "BUSSP") { byte.push_back(0x14); }
		else if (instructionList[i]== "BUSADL") { byte.push_back(0x15); }
		else if (instructionList[i]== "BUSADH") { byte.push_back(0x16); }
		else if (instructionList[i]== "BUSRAM") { byte.push_back(0x19); }
		else if (instructionList[i]== "PCAD") { byte.push_back(0x1A); }
		else if (instructionList[i]== "IOC") { byte.push_back(0x1B); }
		else if (instructionList[i]== "CIO") { byte.push_back(0x1C); }
		else if (instructionList[i]== "ADPC") { byte.push_back(0x1F); }

		else if (instructionList[i]== "NOF") { byte.push_back(0x20); }
		else if (instructionList[i]== "NOTF") { byte.push_back(0x21); }
		else if (instructionList[i]== "ANDF") { byte.push_back(0x22); }
		else if (instructionList[i]== "ORF") { byte.push_back(0x23); }
		else if (instructionList[i]== "CINF") { byte.push_back(0x24); }
		else if (instructionList[i]== "SUBF") { byte.push_back(0x25); }
		else if (instructionList[i]== "LR") { byte.push_back(0x28); }
		else if (instructionList[i]== "RR") { byte.push_back(0x2A); }
		else if (instructionList[i]== "SUBCIN") { byte.push_back(0x2F); }

		else if (instructionList[i]== "ADPCZ") { byte.push_back(0xF1); }
		else if (instructionList[i]== "ADPCN") { byte.push_back(0xF2); }
		else if (instructionList[i]== "ADPCC") { byte.push_back(0xF3); }
		else if (instructionList[i]== "RSTA") { byte.push_back(0xF5); }
		else if (instructionList[i]== "RSTB") { byte.push_back(0xF6); }
		else if (instructionList[i]== "RSTC") { byte.push_back(0xF7); }
		else if (instructionList[i]== "RSTSP") { byte.push_back(0xF8); }
		else if (instructionList[i]== "RSTAD") { byte.push_back(0xF9); }
		else if (instructionList[i]== "RSTPC") { byte.push_back(0xFA); }
		else if (instructionList[i]== "ROMCU") { byte.push_back(0xFB); data = true; }
		else if (instructionList[i]== "DEFHLT") { byte.push_back(0xFC); }
		else if (instructionList[i]== "NOOP") { byte.push_back(0xFD); }
		else if (instructionList[i]== "EI") { byte.push_back(0xFF); }
	}
	
	return byte;
}

std::uint8_t convertNumber(std::string number) {
	if(number[1] == 'd'){
		if (sizeof(number) == 3) { char x[]{ '0','0', number[2] }; return std::stoi(std::string(x), nullptr, 10); }
		if (sizeof(number) == 4) { char x[]{ '0',number[2], number[3] }; return std::stoi(std::string(x), nullptr, 10); }
		if (sizeof(number) == 5) { char x[]{ number[2],number[3],number[4] }; return std::stoi(std::string(x), nullptr, 10); }
	}
	else if (number[1] == 'x') { char x[]{ number[2], number[3] }; return std::stoi(std::string(x), nullptr, 16); }
	else if(number[1] == 'b') { char x[]{ number[2],number[3],number[4],number[5],number[6],number[7],number[8],number[9], }; return std::stoi(std::string(x), nullptr, 2); }
	else {
		std::cout << "\"" << number << "\" is not a correct number; use prefix 0x for hexadecimal, 0d for decimal and 0b for binary\n";
		exit(1);
	}
}

int writeToBin(std::vector<unsigned char> bytelist) {
	std::ofstream romLow("LowROM.bin", std::ios::binary);
	std::ofstream romHigh("HighROM.bin", std::ios::binary);

	if (bytelist.size() < 32768) { std::cout << "INFO: High ROM data is empty."; }
	if (bytelist.size() > 65536) { std::cout << "ERROR: Program is too big for ROM; " << bytelist.size() << "/65536\n"; exit(1); }

	for (int i = 0; i < 65536; i++) {
		if (i >= bytelist.size()) {
			if (i > 32767) {
				romHigh.put(0xFC);
			} else {
				romLow.put(0xFC);
			}
		} else {
			if (i > 32767) {
				romHigh.put(bytelist[i]);
			} else {
				romLow.put(bytelist[i]);
			}
		}
	}
	romLow.close();
	romHigh.close();
	return 0;
}
