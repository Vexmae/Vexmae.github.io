#include <iostream>
#include <fstream>
#include <cstring>
#include <stdlib.h>

#include "Microcode/microMain.h"

int main(int argc, char *argv[]) {
	std::ifstream sourceCode;
	//Basics tests to check if given arguments are correct.
	if (argc != 3) { std::cout << "Too few arguments. Correct command structure: LANGUAGE SOURCE\n\nLANGUAGE -> -A for assembly, -M for mircrocode, -C for Clike\nSOURCE -> Path to input file."; exit(1); }
	
	//Tests if given source file exists.
	
	sourceCode.open(argv[2]);
	if (!sourceCode.is_open()) { std::cout << "Enable to open file \"" << argv[2] << "\"\n"; exit(1); }
	sourceCode.close();

	if (strcmp(argv[1], "-M") == 0 || strcmp(argv[1], "-m") == 0) {
		return microMain(argv[2]);
	} else if (strcmp(argv[1], "-A") == 0 || strcmp(argv[1], "-a") == 0) {
		std::cout << "Not implemented.\n"; exit(0);
	} else if (strcmp(argv[1], "-C") == 0 || strcmp(argv[1], "-c") == 0) {
		std::cout << "Not implemented.\n"; exit(0);
	} else {
		std::cout << "Language \"" << argv[1] << "\" is not a valid language, LANGUAGE -> -A for assembly, -M for mircrocode, -C for Clike\n";
		exit(1);
	}
}