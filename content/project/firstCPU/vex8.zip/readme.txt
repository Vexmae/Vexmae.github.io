Hi ! This zip file contains the vex8 cpu and it's assembler

to use it, open cmd in the same directory as the vex8.exe file, type vex8 -M <path to file>

notes:

Assembler will add a DEF HALT at the end of each program, if the program doesn't loop, it'll halt when it arrives at that instruction 

Assembler will add a NOP at the start of the program to avoid skipping the instruction when reseting

The assembler expects a space or line break between each instruction and expects them in full caps. every character after a ';' is considered comment and will be skipped by the assembler 

To load data from rom, use ROMCU followed by one byte of data.

Data syntax is as follow:

prefix 0d for decimal (from 0 to 255, can have or not leading 0s)
prefix 0x for hexadecimal (from 0x00 to 0xff, must have 2 characters + prefix)
prefix 0b for binary number (from 0b00000000 to 0b11111111, must have 8 characters + prefix)
